from core.plugins.plugin_base import PluginBase


class MenuPluginBase(PluginBase):

    def __init__(self):
        super().__init__()
